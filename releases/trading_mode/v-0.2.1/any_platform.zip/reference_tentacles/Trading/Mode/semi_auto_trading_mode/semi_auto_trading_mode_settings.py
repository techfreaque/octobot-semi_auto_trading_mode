import tentacles.Meta.Keywords.matrix_library.matrix_basic_keywords.mode.trading_mode as trading_mode_basis


class SemiAutoTradingModeSettings(trading_mode_basis.MatrixMode):
    pass
