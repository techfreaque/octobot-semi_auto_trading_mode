from octobot_trading.modes.script_keywords.context_management import Context


async def script(ctx: Context):
    pass
