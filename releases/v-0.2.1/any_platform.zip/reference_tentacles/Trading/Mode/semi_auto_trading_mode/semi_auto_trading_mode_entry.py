# a42.ch CONFIDENTIAL
# __________________
#
#  [2021] - [∞] a42.ch Incorporated
#  All Rights Reserved.
#
# NOTICE:  All information contained herein is, and remains
# the property of a42.ch Incorporated and its suppliers,
# if any.  The intellectual and technical concepts contained
# herein are proprietary to a42.ch Incorporated
# and its suppliers and may be covered by U.S. and Foreign Patents,
# patents in process, and are protected by trade secret or copyright law.
# Dissemination of this information or reproduction of this material
# is strictly forbidden unless prior written permission is obtained
# from a42.ch Incorporated.
#
# If you want to use any code for commercial purposes,
# or you want your own custom solution,
# please contact me contact me at max@a42.ch

import octobot_trading.modes.scripted_trading_mode.abstract_scripted_trading_mode as abstract_scripted_trading_mode
import octobot_trading.enums as trading_enums
import tentacles.Trading.Mode.semi_auto_trading_mode.semi_auto_trading_mode as semi_auto_trading_mode


class SemiAutoTradingMode(abstract_scripted_trading_mode.AbstractScriptedTradingMode):
    AVAILABLE_API_ACTIONS = [semi_auto_trading_mode.SemiAutoTradeCommands.EXECUTE]

    def __init__(self, config, exchange_manager):
        super().__init__(config, exchange_manager)
        self.producer = SemiAutoTradingModeProducer
        import backtesting_script
        import profile_trading_script

        self.register_script_module(profile_trading_script)
        self.register_script_module(backtesting_script, live=False)

    def get_mode_producer_classes(self) -> list:
        return [SemiAutoTradingModeProducer]

    @classmethod
    def get_supported_exchange_types(cls) -> list:
        """
        :return: The list of supported exchange types
        """
        return [
            trading_enums.ExchangeTypes.SPOT,
            trading_enums.ExchangeTypes.FUTURE,
        ]


class SemiAutoTradingModeProducer(semi_auto_trading_mode.SemiAutoTradingModeMaking):
    async def _pre_script_call(self, context, action: dict or str = None):
        await self.make_strategy(context, action)
