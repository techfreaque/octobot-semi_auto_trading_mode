# a42.ch CONFIDENTIAL
# __________________
#
#  [2021] - [∞] a42.ch Incorporated
#  All Rights Reserved.
#
# NOTICE:  All information contained herein is, and remains
# the property of a42.ch Incorporated and its suppliers,
# if any.  The intellectual and technical concepts contained
# herein are proprietary to a42.ch Incorporated
# and its suppliers and may be covered by U.S. and Foreign Patents,
# patents in process, and are protected by trade secret or copyright law.
# Dissemination of this information or reproduction of this material
# is strictly forbidden unless prior written permission is obtained
# from a42.ch Incorporated.
#
# If you want to use any code for commercial purposes,
# or you want your own custom solution,
# please contact me contact me at max@a42.ch

import octobot_trading.modes.script_keywords.basic_keywords as basic_keywords
import tentacles.Meta.Keywords.matrix_library.matrix_pro_keywords.orders.scaled_order as scaled_order
import octobot_trading.modes.script_keywords.context_management as context_management


class ManagedOrderSettingsEntryTypes:
    SINGLE_MARKET_IN = "market_in"
    SINGLE_LIMIT_IN = "limit_in"
    SINGLE_TRY_LIMIT_IN = "try_limit_in"
    SCALED_OVER_TIME = "time_grid_orders"
    SCALED_DYNAMIC = "scaled_entry"
    SCALED_STATIC = "grid_entry"

    SINGLE_MARKET_IN_DESCRIPTION = "Single market in"
    SINGLE_LIMIT_IN_DESCRIPTION = "Single limit in"
    SINGLE_TRY_LIMIT_IN_DESCRIPTION = "Single try limit in"
    SCALED_OVER_TIME_DESCRIPTION = "Scale entry orders over time"
    SCALED_DYNAMIC_DESCRIPTION = "Scale limit orders over a dynamic price range"
    SCALED_STATIC_DESCRIPTION = "Scale limit orders over a static price range"

    KEY_TO_DESCRIPTIONS = {
        SINGLE_MARKET_IN: SINGLE_MARKET_IN_DESCRIPTION,
        SINGLE_LIMIT_IN: SINGLE_LIMIT_IN_DESCRIPTION,
        SINGLE_TRY_LIMIT_IN: SINGLE_TRY_LIMIT_IN_DESCRIPTION,
        SCALED_OVER_TIME: SCALED_OVER_TIME_DESCRIPTION,
        SCALED_DYNAMIC_DESCRIPTION: SCALED_DYNAMIC_DESCRIPTION,
        SCALED_STATIC: SCALED_STATIC_DESCRIPTION,
    }
    DESCRIPTIONS = [
        SINGLE_MARKET_IN_DESCRIPTION,
        SINGLE_LIMIT_IN_DESCRIPTION,
        SINGLE_TRY_LIMIT_IN_DESCRIPTION,
        SCALED_OVER_TIME_DESCRIPTION,
        SCALED_DYNAMIC_DESCRIPTION,
        SCALED_STATIC_DESCRIPTION,
    ]


class ManagedOrderSettingsEntry:
    def __init__(self) -> None:
        self.ctx: context_management.Context = None

        self.entry_path: str = None
        self.entry_setting_name: str = None

        self.entry_type: str = None
        self.limit_offset: float = None
        self.slippage_limit: float = None
        self.market_in_if_limit_fails: bool = None
        self.entry_scaled_min: float = None
        self.entry_scaled_max: float = None
        self.entry_scaled_order_count: int = None
        self.scaled_entry_price_distribution_type: str = None
        self.scaled_entry_price_growth_factor: float = None
        self.scaled_entry_value_distribution_type: str = None
        self.scaled_entry_value_growth_factor: float = None
        self.entry_scaled_min: float = None
        self.entry_scaled_max: float = None

    async def initialize_entry_settings(self):
        # entry type
        self.entry_type = await basic_keywords.user_input(
            self.ctx,
            "entry type",
            "options",
            ManagedOrderSettingsEntryTypes.SINGLE_MARKET_IN_DESCRIPTION,
            options=ManagedOrderSettingsEntryTypes.DESCRIPTIONS,
            path=self.entry_path,
            parent_input_name=self.entry_setting_name,
        )
        # entry: limit in
        if (
            self.entry_type
            == ManagedOrderSettingsEntryTypes.SINGLE_MARKET_IN_DESCRIPTION
        ):
            self.limit_offset = await basic_keywords.user_input(
                self.ctx,
                "limit entry offset in %",
                "float",
                0.2,
                min_val=0,
                path=self.entry_path,
                parent_input_name=self.entry_setting_name,
            )

        # entry: try limit in
        if (
            self.entry_type
            == ManagedOrderSettingsEntryTypes.SINGLE_TRY_LIMIT_IN_DESCRIPTION
        ):
            self.slippage_limit = await basic_keywords.user_input(
                self.ctx,
                "Slippage Limit: can be % or price",
                "float",
                40,
                path=self.entry_path,
                parent_input_name=self.entry_setting_name,
            )
            self.market_in_if_limit_fails = await basic_keywords.user_input(
                self.ctx,
                "try to limit in",
                "boolean",
                True,
                path=self.entry_path,
                parent_input_name=self.entry_setting_name,
            )

        if self.entry_type == ManagedOrderSettingsEntryTypes.SCALED_DYNAMIC_DESCRIPTION:
            self.entry_scaled_min = await basic_keywords.user_input(
                self.ctx,
                "scale limit orders from: (measured in %) ",
                "float",
                1,
                min_val=0,
                path=self.entry_path,
                parent_input_name=self.entry_setting_name,
            )
            self.entry_scaled_max = await basic_keywords.user_input(
                self.ctx,
                "scale limit orders to: (measured in %",
                "float",
                2,
                min_val=0,
                path=self.entry_path,
                parent_input_name=self.entry_setting_name,
            )
            self.entry_scaled_order_count = await basic_keywords.user_input(
                self.ctx,
                "amount of entry orders",
                "int",
                10,
                min_val=2,
                path=self.entry_path,
                parent_input_name=self.entry_setting_name,
            )

        if self.entry_type == ManagedOrderSettingsEntryTypes.SCALED_STATIC_DESCRIPTION:
            self.scaled_entry_price_distribution_type = await basic_keywords.user_input(
                self.ctx,
                "Grid price distribution type",
                "options",
                scaled_order.ScaledOrderPriceDistributionTypes.LINEAR_GROWTH,
                options=scaled_order.ScaledOrderPriceDistributionTypes.all_types,
                path=self.entry_path,
                parent_input_name=self.entry_setting_name,
            )
            if self.scaled_entry_price_distribution_type in (
                scaled_order.ScaledOrderPriceDistributionTypes.LINEAR_GROWTH,
                scaled_order.ScaledOrderPriceDistributionTypes.EXPONENTIAL,
            ):
                self.scaled_entry_price_growth_factor = await basic_keywords.user_input(
                    self.ctx,
                    "Scale price growth rate",
                    "float",
                    2,
                    min_val=0.0000001,
                    path=self.entry_path,
                    max_val=100,
                    parent_input_name=self.entry_setting_name,
                )
            self.entry_scaled_order_count = await basic_keywords.user_input(
                self.ctx,
                "amount of orders",
                "int",
                10,
                min_val=2,
                path=self.entry_path,
                parent_input_name=self.entry_setting_name,
            )

            self.scaled_entry_value_distribution_type = await basic_keywords.user_input(
                self.ctx,
                "Grid value distribution type",
                "options",
                scaled_order.ScaledOrderValueDistributionTypes.LINEAR_GROWTH,
                options=scaled_order.ScaledOrderValueDistributionTypes.all_types,
                path=self.entry_path,
                parent_input_name=self.entry_setting_name,
            )
            if self.scaled_entry_value_distribution_type in (
                scaled_order.ScaledOrderValueDistributionTypes.LINEAR_GROWTH,
                scaled_order.ScaledOrderValueDistributionTypes.EXPONENTIAL,
            ):
                self.scaled_entry_value_growth_factor = await basic_keywords.user_input(
                    self.ctx,
                    "scale value growth rate",
                    "float",
                    2,
                    min_val=0.0000001,
                    path=self.entry_path,
                    max_val=100,
                    parent_input_name=self.entry_setting_name,
                )
            self.entry_scaled_min = await basic_keywords.user_input(
                self.ctx,
                "scale limit orders from price",
                "float",
                1,
                min_val=0,
                path=self.entry_path,
                parent_input_name=self.entry_setting_name,
            )
            self.entry_scaled_max = await basic_keywords.user_input(
                self.ctx,
                "scale limit orders to price",
                "float",
                2,
                min_val=0,
                path=self.entry_path,
                parent_input_name=self.entry_setting_name,
            )
