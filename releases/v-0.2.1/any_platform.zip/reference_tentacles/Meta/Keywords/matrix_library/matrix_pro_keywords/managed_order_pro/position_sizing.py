# a42.ch CONFIDENTIAL
# __________________
#
#  [2021] - [∞] a42.ch Incorporated
#  All Rights Reserved.
#
# NOTICE:  All information contained herein is, and remains
# the property of a42.ch Incorporated and its suppliers,
# if any.  The intellectual and technical concepts contained
# herein are proprietary to a42.ch Incorporated
# and its suppliers and may be covered by U.S. and Foreign Patents,
# patents in process, and are protected by trade secret or copyright law.
# Dissemination of this information or reproduction of this material
# is strictly forbidden unless prior written permission is obtained
# from a42.ch Incorporated.
#
# If you want to use any code for commercial purposes,
# or you want your own custom solution,
# please contact me contact me at max@a42.ch

import decimal as decimal
import tentacles.Meta.Keywords.matrix_library.matrix_pro_keywords.managed_order_pro.settings.position_size_settings as size_settings
import tentacles.Meta.Keywords.matrix_library.matrix_pro_keywords.managed_order_pro.settings.sl_settings as sl_settings
import tentacles.Meta.Keywords.matrix_library.matrix_pro_keywords.managed_order_pro.stop_losses.stop_loss_handling as stop_loss_handling
import tentacles.Meta.Keywords.matrix_library.matrix_pro_keywords.managed_order_pro.utilities as utilities
import tentacles.Meta.Keywords.scripting_library.data.reading.exchange_public_data as exchange_public_data
import tentacles.Meta.Keywords.scripting_library.data.reading.exchange_private_data.open_positions as open_positions
import octobot_trading.modes.script_keywords.basic_keywords.account_balance as account_balance
import octobot_trading.enums as trading_enums


class ManagedOrderPositionSizing(utilities.ManagedOrderUtilities):
    def __init__(self):
        super().__init__()
        self.market_fee = 0
        self.limit_fee = 0
        self.entry_fees = 0
        self.exit_fee = 0
        self.position_size_market = 0
        self.position_size_limit = 0
        self.current_open_risk = 0
        self.max_position_size = 0
        self.max_buying_power = 0
        self.place_entries = False

        self.sl_price = 0
        self.sl_in_p = 0
        self.sl_indicator_value = 0
        self.expected_entry_price = 0
        self.entry_price = 0
        self.current_price_val = 0

    async def set_managed_position_size(self, ctx):

        # SL get stop loss to calculate position size

        if (
            self.managed_orders_settings.sl_type
            != sl_settings.ManagedOrderSettingsSLTypes.NO_SL_DESCRIPTION
        ):
            self.sl_indicator_value = self.sl_indicator_value
            (
                self.sl_price,
                self.sl_in_p,
                self.expected_entry_price,
            ) = await stop_loss_handling.get_manged_order_stop_loss(
                ctx=ctx,
                managed_orders_settings=self.managed_orders_settings,
                trading_side=self.trading_side,
                sl_indicator_value=self.sl_indicator_value,
            )
        else:
            self.expected_entry_price = float(
                await exchange_public_data.current_live_price(ctx)
            )

        # position size

        fees = exchange_public_data.symbol_fees(ctx)
        fallback_fees = fees.get("fee", 0)
        self.limit_fee = (
            float(fallback_fees if fees["maker"] is None else fees["maker"]) * 100
        )
        self.market_fee = (
            float(fallback_fees if fees["taker"] is None else fees["taker"]) * 100
        )

        # position size based on dollar/reference market risk
        if (
            self.managed_orders_settings.position_size_type
            == size_settings.ManagedOrderSettingsPositionSizeTypes.QUANTITY_RISK_OF_ACCOUNT_DESCRIPTION
        ):
            self.position_size_market = (
                (self.managed_orders_settings.risk_in_d / self.expected_entry_price)
                / (self.sl_in_p + (self.market_fee + self.market_fee))
            ) / 0.01
            self.position_size_limit = (
                (self.managed_orders_settings.risk_in_d / self.expected_entry_price)
                / (self.sl_in_p + (self.limit_fee + self.market_fee))
            ) / 0.01
            self.exit_fee = self.market_fee  # todo use entry fees instead
            self.current_open_risk = await self.get_current_open_risk(ctx)

            self.max_position_size = (
                (
                    (
                        self.managed_orders_settings.total_risk_in_d
                        / self.expected_entry_price
                    )
                    - self.current_open_risk
                )
                / (self.sl_in_p + (2 * self.market_fee))
            ) / 0.01

        # position size based risk per trade in percent
        elif (
            self.managed_orders_settings.position_size_type
            == size_settings.ManagedOrderSettingsPositionSizeTypes.PERCENT_RISK_OF_ACCOUNT_DESCRIPTION
        ):
            current_total_acc_balance = float(
                await account_balance.total_account_balance(ctx)
            )
            risk_in_d = (
                self.managed_orders_settings.risk_in_p / 100
            ) * current_total_acc_balance

            self.position_size_market = (
                risk_in_d / (self.sl_in_p + (2 * self.market_fee))
            ) / 0.01
            self.position_size_limit = (
                risk_in_d / (self.sl_in_p + self.limit_fee + self.market_fee)
            ) / 0.01
            self.exit_fee = self.market_fee  # todo use entry fees instead
            self.current_open_risk = await self.get_current_open_risk(ctx)

            total_risk_in_d = (
                self.managed_orders_settings.total_risk_in_p / 100
            ) * current_total_acc_balance - self.current_open_risk
            self.max_position_size = (
                total_risk_in_d / (self.sl_in_p + (2 * self.market_fee))
            ) / 0.01

        # position size based on percent of total account balance
        elif (
            self.managed_orders_settings.position_size_type
            == size_settings.ManagedOrderSettingsPositionSizeTypes.PERCENT_OF_ACCOUNT_DESCRIPTION
        ):
            current_total_acc_balance = float(
                await account_balance.total_account_balance(ctx)
            )
            self.position_size_market = (
                self.managed_orders_settings.risk_in_p / 100
            ) * current_total_acc_balance
            self.position_size_limit = self.position_size_market
            current_open_position_size = open_positions.open_position_size(
                ctx, side="both"
            )

            if self.trading_side == trading_enums.PositionSide.SHORT.value:
                current_open_position_size *= -1
            self.max_position_size = (
                self.managed_orders_settings.total_risk_in_p / 100
            ) * current_total_acc_balance

        self.max_position_size = float(
            exchange_public_data.get_digits_adapted_amount(
                ctx, decimal.Decimal(self.max_position_size)
            )
        )

        self.max_buying_power = float(
            exchange_public_data.get_digits_adapted_amount(
                ctx,
                await account_balance.available_account_balance(
                    ctx, side=self.entry_side, reduce_only=False
                ),
            )
        )

        # check if enough balance for requested size and cut if necessary
        if self.max_buying_power < self.position_size_market:
            self.position_size_market = self.max_buying_power
            self.position_size_limit = self.max_buying_power

        # cut the position size so that it aligns with target risk
        if self.position_size_market > self.max_position_size:
            self.position_size_limit = self.max_position_size
            self.position_size_market = self.max_position_size

        self.position_size_limit = float(
            exchange_public_data.get_digits_adapted_amount(
                ctx, decimal.Decimal(self.position_size_limit)
            )
        )
        self.position_size_market = float(
            exchange_public_data.get_digits_adapted_amount(
                ctx, decimal.Decimal(self.position_size_market)
            )
        )
        if self.position_size_market == 0:
            ctx.logger.warning(
                "Managed order cant open a new position, "
                "the digits adapted price is 0. Make sure the position size"
                f" is at least the minimum size required by the exchange for {ctx.symbol}"
            )
            return
        if self.position_size_market < 0:
            ctx.logger.info(
                "Managed order cant open a new position, maximum position size is reached"
            )
            return
        self.place_entries = True

    async def get_current_open_risk(self, ctx):
        current_average_long_entry = float(
            await open_positions.average_open_pos_entry(ctx, side="long")
        )
        current_average_short_entry = float(
            await open_positions.average_open_pos_entry(ctx, side="short")
        )
        current_open_orders = (
            ctx.exchange_manager.exchange_personal_data.orders_manager.orders
        )
        current_open_risk = 0
        for order in current_open_orders:
            if (
                current_open_orders[order].order_type
                == trading_enums.TraderOrderType.STOP_LOSS
            ):
                if current_open_orders[order].side == trading_enums.TradeOrderSide.SELL:
                    stop_loss_distance = current_average_long_entry - float(
                        current_open_orders[order].origin_price
                    )
                else:
                    stop_loss_distance = (
                        float(current_open_orders[order].origin_price)
                        - current_average_short_entry
                    )
                current_open_risk += ((self.market_fee + self.exit_fee) / 100) * float(
                    current_open_orders[order].origin_quantity
                ) + (
                    float(current_open_orders[order].origin_quantity)
                    * stop_loss_distance
                    / float(current_open_orders[order].origin_price)
                )
        return current_open_risk
