# a42.ch CONFIDENTIAL
# __________________
#
#  [2021] - [∞] a42.ch Incorporated
#  All Rights Reserved.
#
# NOTICE:  All information contained herein is, and remains
# the property of a42.ch Incorporated and its suppliers,
# if any.  The intellectual and technical concepts contained
# herein are proprietary to a42.ch Incorporated
# and its suppliers and may be covered by U.S. and Foreign Patents,
# patents in process, and are protected by trade secret or copyright law.
# Dissemination of this information or reproduction of this material
# is strictly forbidden unless prior written permission is obtained
# from a42.ch Incorporated.
#
# If you want to use any code for commercial purposes,
# or you want your own custom solution,
# please contact me contact me at max@a42.ch

import octobot_trading.modes.script_keywords.basic_keywords as basic_keywords
import octobot_trading.enums as trading_enums
import octobot_trading.constants as trading_constants
import tentacles.Meta.Keywords.matrix_library.matrix_pro_keywords.managed_order_pro.settings.entry_settings as entry_settings
import tentacles.Meta.Keywords.matrix_library.matrix_pro_keywords.managed_order_pro.settings.sl_settings as sl_settings
import tentacles.Meta.Keywords.matrix_library.matrix_pro_keywords.managed_order_pro.settings.tp_settings as tp_settings
import tentacles.Meta.Keywords.scripting_library.orders.order_types as order_types
import tentacles.Meta.Keywords.scripting_library.orders.grouping as grouping
import tentacles.Meta.Keywords.scripting_library.orders.waiting as waiting
import tentacles.Meta.Keywords.matrix_library.matrix_pro_keywords.managed_order_pro.position_sizing as position_sizing
import tentacles.Meta.Keywords.matrix_library.matrix_pro_keywords.managed_order_pro.take_profits as take_profits
import tentacles.Meta.Keywords.matrix_library.matrix_pro_keywords.orders.scaled_order as scaled_order


class ManagedOrderPlacement(position_sizing.ManagedOrderPositionSizing):
    def __init__(self):
        super().__init__()
        self.sl_offset = None
        self.sl_tag = None
        self.entry_type = ""
        self.profit_in_p = 0
        self.profit_in_d = 0

    async def place_managed_entry_and_stop_orders(self, ctx):
        # ensure leverage is up to date
        await basic_keywords.user_select_leverage(ctx)
        await basic_keywords.set_partial_take_profit_stop_loss(ctx)

        # stop loss
        sl_offset: str = None
        sl_tag: str = None
        if (
            sl_settings.ManagedOrderSettingsSLTypes.NO_SL_DESCRIPTION
            != self.managed_orders_settings.sl_type
        ):
            self.sl_offset = f"@{self.sl_price}"
            self.sl_tag = self.exit_order_tag
            if self.managed_orders_settings.use_bundled_sl_orders:
                sl_offset = self.sl_offset
                sl_tag = self.sl_tag

        # entry

        self.entry_type = "market"
        if (
            self.managed_orders_settings.entry_type
            == entry_settings.ManagedOrderSettingsEntryTypes.SINGLE_TRY_LIMIT_IN_DESCRIPTION
        ):
            # entry try limit in
            # todo + handle on backtesting (maybe use always 1m to check if it got filled)
            # entry_type = "limit"
            # created_orders = await order_types.trailing_limit(ctx, amount=position_size_limit, side=entry_side,
            #                                                   min_offset=0, max_offset=0,
            #                                                   slippage_limit=self.managed_orders_settings.slippage_limit,
            #                                                   tag=entry_order_tag, stop_loss_offset=sl_offset,
            #                                                   stop_loss_tag=sl_tag)
            # # wait for limit to get filled
            # if tag_triggered.tagged_order_unfilled(entry_order_tag):
            #     unfilled_amount = tag_triggered.tagged_order_unfilled_amount(entry_order_tag)
            #     if unfilled_amount != position_size_limit:
            #         position_size_market = 50  # todo calc smaller size cause of fees
            #     created_orders = await order_types.market(ctx, side=entry_side, amount=position_size_market,
            #                                               tag=entry_order_tag, stop_loss_offset=sl_offset,
            #                                               stop_loss_tag=sl_tag)
            raise NotImplementedError("managed order: try limit in not implemented yet")

        # entry market in only
        elif (
            self.managed_orders_settings.entry_type
            == entry_settings.ManagedOrderSettingsEntryTypes.SINGLE_MARKET_IN_DESCRIPTION
        ):
            self.created_orders = await order_types.market(
                ctx,
                side=self.entry_side,
                amount=self.position_size_market,
                tag=self.entry_order_tag,
                stop_loss_offset=sl_offset,
                stop_loss_tag=sl_tag,
                stop_loss_group=self.order_group,
            )

        # entry limit in only
        elif (
            self.managed_orders_settings.entry_type
            == entry_settings.ManagedOrderSettingsEntryTypes.SINGLE_LIMIT_IN_DESCRIPTION
        ):
            self.entry_type = "limit"
            self.created_orders = await order_types.limit(
                ctx,
                side=self.entry_side,
                amount=self.position_size_limit,
                offset=f"-{self.managed_orders_settings.limit_offset}%",
                tag=self.entry_order_tag,
                stop_loss_offset=sl_offset,
                stop_loss_tag=sl_tag,
                stop_loss_group=self.order_group,
            )

        # entry scaled limits
        elif (
            self.managed_orders_settings.entry_type
            == entry_settings.ManagedOrderSettingsEntryTypes.SCALED_DYNAMIC_DESCRIPTION
        ):
            self.entry_type = "limit"
            if self.entry_side == trading_enums.TradeOrderSide.BUY.value:
                scale_from = f"-{self.managed_orders_settings.entry_scaled_max}%"
                scale_to = f"-{self.managed_orders_settings.entry_scaled_min}%"
            else:
                scale_from = f"{self.managed_orders_settings.entry_scaled_min}%"
                scale_to = f"{self.managed_orders_settings.entry_scaled_max}%"

            self.created_orders = await order_types.scaled_limit(
                ctx,
                side=self.entry_side,
                amount=self.position_size_limit,
                scale_from=scale_from,
                scale_to=scale_to,
                order_count=self.managed_orders_settings.entry_scaled_order_count,
                tag=self.entry_order_tag,
                stop_loss_offset=sl_offset,
                stop_loss_tag=sl_tag,
                stop_loss_group=self.order_group,
            )

        # entry grid limits
        elif (
            self.managed_orders_settings.entry_type
            == entry_settings.ManagedOrderSettingsEntryTypes.SCALED_STATIC_DESCRIPTION
        ):
            self.entry_type = "limit"
            # from to can be swapped with no difference
            scale_from = f"@{self.managed_orders_settings.entry_scaled_max}"
            scale_to = f"@{self.managed_orders_settings.entry_scaled_min}"

            self.created_orders = await scaled_order.scaled_order(
                ctx,
                side=self.entry_side,
                # amount=,
                scale_from=scale_from,
                scale_to=scale_to,
                order_count=self.managed_orders_settings.entry_scaled_order_count,
                tag=self.entry_order_tag,
                stop_loss_offset=sl_offset,
                stop_loss_tag=sl_tag,
                value_distribution_type=self.managed_orders_settings.scaled_entry_value_distribution_type,
                value_growth_factor=self.managed_orders_settings.scaled_entry_value_growth_factor,
                price_distribution_type=self.managed_orders_settings.scaled_entry_price_distribution_type,
                price_growth_factor=self.managed_orders_settings.scaled_entry_price_growth_factor,
                stop_loss_group=self.order_group,
            )
        # entry time grid orders
        elif (
            self.managed_orders_settings.entry_type
            == entry_settings.ManagedOrderSettingsEntryTypes.SCALED_OVER_TIME_DESCRIPTION
        ):
            raise NotImplementedError("time grid orders not implemented yet")
        else:
            raise NotImplementedError("Unknown entry order type")

        if (
            self.created_orders
            and not self.managed_orders_settings.use_bundled_sl_orders
        ):
            # todo make sure it uses actutal size
            await order_types.stop_loss(
                ctx,
                side=self.exit_side,
                offset=self.sl_offset,
                amount=self.position_size_limit
                if self.entry_type == "limit"
                else self.position_size_market,
                tag=self.sl_tag,
                group=self.order_group,
            )
        return self

    async def place_managed_exit_orders(self, ctx):
        if not self.created_orders or (
            self.created_orders[0] is None and len(self.created_orders) == 1
        ):
            # no entry created: do not create exits
            return

        # create order group if necessary
        await self.handle_manged_order_group(ctx)

        # in real treading wait for orders and modify SL if necessary
        if (
            ctx.exchange_manager.trader.trader_type_str
            == trading_constants.REAL_TRADER_STR
            and self.managed_orders_settings.adapt_live_exits
        ):
            await self.handle_managed_real_trading_orders(ctx)

        # place take profits
        # todo use offset from entry instead of current price
        await self.place_managed_take_profits(ctx)

        if self.enabled_order_group:
            await grouping.enable_group(self.order_group, True)

    async def place_managed_take_profits(self, ctx):
        self.entry_price = (
            self.entry_price
            or float(self.created_orders[0].filled_price)
            or self.expected_entry_price
        )
        # take profits
        if (
            tp_settings.ManagedOrderSettingsTPTypes.NO_TP_DESCRIPTION
            != self.managed_orders_settings.tp_type
        ):
            # take profit based on risk reward
            if (
                self.managed_orders_settings.tp_type
                == tp_settings.ManagedOrderSettingsTPTypes.SINGLE_RISK_REWARD_DESCRIPTION
            ):
                await take_profits.take_profit_based_on_risk_reward(self, ctx)

            # scaled take profit based on risk reward
            elif (
                self.managed_orders_settings.tp_type
                == tp_settings.ManagedOrderSettingsTPTypes.SCALED_RISK_REWARD_DESCRIPTION
            ):
                await take_profits.take_profit_scaled_based_on_risk_reward(self, ctx)

            # take profit based on percent
            elif (
                self.managed_orders_settings.tp_type
                == tp_settings.ManagedOrderSettingsTPTypes.SINGLE_PERCENT_DESCRIPTION
            ):
                await take_profits.take_profit_based_on_percent(self, ctx)

            # scaled take profit based on percent
            elif (
                self.managed_orders_settings.tp_type
                == tp_settings.ManagedOrderSettingsTPTypes.SCALED_PERCENT_DESCRIPTION
            ):
                await take_profits.take_profit_scaled_based_on_percent(self, ctx)

    async def handle_managed_real_trading_orders(self, ctx):
        if (
            sl_settings.ManagedOrderSettingsSLTypes.NO_SL_DESCRIPTION
            != self.managed_orders_settings.sl_type
        ):
            # todo create task - takes ages and blocks from finishing - but wait for that with the notification
            if self.entry_type == "market":
                pass
                # edit stop loss to accurate values once market is filled
                # await asyncio.sleep(10)
                # try:
                #     await stop_losses.adjust_managed_stop_loss(ctx, self.managed_orders_settings, self)
                # except Exception as e:
                #     ctx.logger.error(f"Managed Order: adapting stop loss based on filled price failed. (error: {e})")
                #     self.enabled_order_group = False
                #     # in case it fails continue anyway creating take profits
            else:  # limit orders
                # for limit orders we wait for the stop loss to be placed
                await waiting.wait_for_stop_loss_open(
                    ctx, self.created_orders, timeout=60
                )
