# a42.ch CONFIDENTIAL
# __________________
#
#  [2021] - [∞] a42.ch Incorporated
#  All Rights Reserved.
#
# NOTICE:  All information contained herein is, and remains
# the property of a42.ch Incorporated and its suppliers,
# if any.  The intellectual and technical concepts contained
# herein are proprietary to a42.ch Incorporated
# and its suppliers and may be covered by U.S. and Foreign Patents,
# patents in process, and are protected by trade secret or copyright law.
# Dissemination of this information or reproduction of this material
# is strictly forbidden unless prior written permission is obtained
# from a42.ch Incorporated.
#
# If you want to use any code for commercial purposes,
# or you want your own custom solution,
# please contact me contact me at max@a42.ch

import tentacles.Meta.Keywords.scripting_library.orders.order_types as order_types
import octobot_trading.enums as trading_enums


async def take_profit_scaled_based_on_percent(self, ctx):
    if self.entry_side == trading_enums.TradeOrderSide.BUY.value:
        scale_from = self.entry_price * (
            1 + (self.managed_orders_settings.p_tp_min / 100)
        )
        scale_from = f"@{scale_from}"
        scale_to = self.entry_price * (
            1 + (self.managed_orders_settings.p_tp_max / 100)
        )
        scale_to = f"@{scale_to}"
    else:
        scale_from = self.entry_price * (
            1 + (self.managed_orders_settings.p_tp_max / 100)
        )
        scale_from = f"@{scale_from}"
        scale_to = self.entry_price * (
            1 + (self.managed_orders_settings.p_tp_min / 100)
        )
        scale_to = f"@{scale_to}"

    await order_types.scaled_limit(
        ctx,
        side=self.exit_side,
        amount=self.exit_amount,
        target_position=self.exit_target_position,
        scale_from=scale_from,
        scale_to=scale_to,
        order_count=self.managed_orders_settings.p_tp_order_count,
        group=self.order_group,
        tag=self.exit_order_tag,
        reduce_only=True,
        wait_for=self.created_orders,
    )


async def take_profit_based_on_percent(self, ctx):
    self.profit_in_d = (
        self.entry_price * (1 + (self.managed_orders_settings.tp_in_p / 100))
        if self.entry_side == trading_enums.TradeOrderSide.BUY.value
        else self.entry_price * (1 - (self.managed_orders_settings.tp_in_p / 100))
    )
    await order_types.limit(
        ctx,
        side=self.exit_side,
        amount=self.exit_amount,
        target_position=self.exit_target_position,
        offset=f"@{self.profit_in_d}",
        group=self.order_group,
        tag=self.exit_order_tag,
        reduce_only=True,
        wait_for=self.created_orders,
    )


async def take_profit_scaled_based_on_risk_reward(self, ctx):
    self.entry_fees = self.market_fee if self.entry_type == "market" else self.limit_fee
    if self.entry_side == trading_enums.TradeOrderSide.BUY.value:
        scale_from = self.entry_price * (
            1
            + (
                self.managed_orders_settings.rr_tp_min
                * (self.sl_in_p + self.market_fee + self.entry_fees)
                / 100
            )
        )
        scale_from = f"@{scale_from}"
        scale_to = self.entry_price * (
            1
            + (
                self.managed_orders_settings.rr_tp_max
                * (self.sl_in_p + self.market_fee + self.entry_fees)
                / 100
            )
        )
        scale_to = f"@{scale_to}"
    else:
        scale_from = self.entry_price * (
            1
            - (
                self.managed_orders_settings.rr_tp_max
                * (self.sl_in_p + self.market_fee + self.entry_fees)
                / 100
            )
        )
        scale_from = f"@{scale_from}"
        scale_to = self.entry_price * (
            1
            - (
                self.managed_orders_settings.rr_tp_min
                * (self.sl_in_p + self.market_fee + self.entry_fees)
                / 100
            )
        )
        scale_to = f"@{scale_to}"

    await order_types.scaled_limit(
        ctx,
        side=self.exit_side,
        amount=self.exit_amount,
        target_position=self.exit_target_position,
        scale_from=scale_from,
        scale_to=scale_to,
        order_count=self.managed_orders_settings.rr_tp_order_count,
        group=self.order_group,
        tag=self.exit_order_tag,
        reduce_only=True,
        wait_for=self.created_orders,
    )


async def take_profit_based_on_risk_reward(self, ctx):
    self.entry_fees = self.market_fee if self.entry_type == "market" else self.limit_fee
    if self.entry_side == trading_enums.TradeOrderSide.BUY.value:
        self.profit_in_p = self.managed_orders_settings.tp_rr * (
            self.sl_in_p + self.market_fee + self.entry_fees
        )
        self.profit_in_d = self.entry_price * (1 + (self.profit_in_p / 100))
    else:
        self.profit_in_p = self.managed_orders_settings.tp_rr * (
            self.sl_in_p + self.market_fee + self.entry_fees
        )
        self.profit_in_d = self.entry_price * (1 - (self.profit_in_p / 100))

    await order_types.limit(
        ctx,
        side=self.exit_side,
        amount=self.exit_amount,
        target_position=self.exit_target_position,
        offset=f"@{self.profit_in_d}",
        group=self.order_group,
        tag=self.exit_order_tag,
        reduce_only=True,
        wait_for=self.created_orders,
    )
